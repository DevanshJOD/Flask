import React from "react"

class LandingPage extends React.Component {

    componentDidMount() {
        // load data from API
    }

    render() {
        return <div>Landing Page</div>
    }
}

export default LandingPage
